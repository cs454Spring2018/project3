# project3

The dfa equivalence code is in finalunionfind.py
The dfa minimization code is in dfa_minimization.py
